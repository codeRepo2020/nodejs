module.exports = {
    "extends": "standard",
};