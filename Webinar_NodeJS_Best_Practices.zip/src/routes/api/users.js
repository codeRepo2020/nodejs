const route = require('express').Router()

module.exports = route
