module.exports = {
    "extends": "standard",
};